import { Users, Clock, Calendar, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const DashboardStats = () => {
  const stats = [
    {
      title: "Toplam Çalışan",
      value: "24",
      change: "+2 bu ay",
      icon: Users,
      color: "primary",
    },
    {
      title: "Aktif Vardiyalar",
      value: "8",
      change: "Bugün",
      icon: Clock,
      color: "secondary",
    },
    {
      title: "Bu Hafta",
      value: "152",
      change: "Toplam saat",
      icon: Calendar,
      color: "info",
    },
    {
      title: "Verimlilik",
      value: "94%",
      change: "+5% artış",
      icon: TrendingUp,
      color: "success",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <Card
          key={index}
          className="shadow-md border-border/50 hover:shadow-lg transition-all bg-gradient-card"
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div
                className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  stat.color === "primary"
                    ? "bg-primary/10"
                    : stat.color === "secondary"
                    ? "bg-secondary/10"
                    : stat.color === "info"
                    ? "bg-info/10"
                    : "bg-success/10"
                }`}
              >
                <stat.icon
                  className={`w-6 h-6 ${
                    stat.color === "primary"
                      ? "text-primary"
                      : stat.color === "secondary"
                      ? "text-secondary"
                      : stat.color === "info"
                      ? "text-info"
                      : "text-success"
                  }`}
                />
              </div>
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-1">{stat.title}</h3>
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-bold text-foreground">{stat.value}</p>
              <span className="text-xs text-muted-foreground">{stat.change}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DashboardStats;
