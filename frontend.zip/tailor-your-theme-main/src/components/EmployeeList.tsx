import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

const EmployeeList = () => {
  const employees = [
    { name: "Ahmet Yılmaz", role: "Vardiya Lideri", status: "active", initials: "AY" },
    { name: "Ayşe Kaya", role: "Çalışan", status: "active", initials: "AK" },
    { name: "Mehmet Demir", role: "Çalışan", status: "active", initials: "MD" },
    { name: "Fatma Şahin", role: "Çalışan", status: "break", initials: "FŞ" },
    { name: "Ali Öztürk", role: "Vardiya Lideri", status: "active", initials: "AÖ" },
    { name: "Zeynep Arslan", role: "Çalışan", status: "active", initials: "ZA" },
  ];

  return (
    <div className="space-y-3">
      {employees.map((employee, index) => (
        <div
          key={index}
          className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
        >
          <Avatar className="h-10 w-10 border-2 border-primary/20">
            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
              {employee.initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">{employee.name}</p>
            <p className="text-xs text-muted-foreground">{employee.role}</p>
          </div>
          <Badge
            variant={employee.status === "active" ? "default" : "secondary"}
            className="text-xs"
          >
            {employee.status === "active" ? "Aktif" : "Mola"}
          </Badge>
        </div>
      ))}
    </div>
  );
};

export default EmployeeList;
