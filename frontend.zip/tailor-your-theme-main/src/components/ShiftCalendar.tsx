import { Badge } from "@/components/ui/badge";

const ShiftCalendar = () => {
  const days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"];
  
  const shifts = [
    { day: 0, time: "08:00-16:00", employee: "Ahmet Yılmaz", type: "morning" },
    { day: 0, time: "16:00-00:00", employee: "Mehmet Demir", type: "evening" },
    { day: 1, time: "08:00-16:00", employee: "Ayşe Kaya", type: "morning" },
    { day: 1, time: "16:00-00:00", employee: "Fatma Şahin", type: "evening" },
    { day: 2, time: "08:00-16:00", employee: "Ali Öztürk", type: "morning" },
    { day: 2, time: "16:00-00:00", employee: "Zeynep Arslan", type: "evening" },
    { day: 3, time: "08:00-16:00", employee: "Ahmet Yılmaz", type: "morning" },
    { day: 3, time: "16:00-00:00", employee: "Mehmet Demir", type: "evening" },
    { day: 4, time: "08:00-16:00", employee: "Ayşe Kaya", type: "morning" },
    { day: 4, time: "16:00-00:00", employee: "Fatma Şahin", type: "evening" },
    { day: 5, time: "09:00-17:00", employee: "Ali Öztürk", type: "morning" },
    { day: 6, time: "09:00-17:00", employee: "Zeynep Arslan", type: "morning" },
  ];

  return (
    <div className="space-y-4">
      {days.map((day, index) => (
        <div key={index} className="border-b border-border pb-3 last:border-0">
          <h4 className="font-semibold text-foreground mb-2">{day}</h4>
          <div className="space-y-2">
            {shifts
              .filter((shift) => shift.day === index)
              .map((shift, shiftIndex) => (
                <div
                  key={shiftIndex}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Badge
                      variant={shift.type === "morning" ? "default" : "secondary"}
                      className="font-mono text-xs"
                    >
                      {shift.time}
                    </Badge>
                    <span className="text-sm text-foreground">{shift.employee}</span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ShiftCalendar;
