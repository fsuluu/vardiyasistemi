import { Calendar, Users, Clock, BarChart3, Settings, CalendarDays, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import DashboardStats from "@/components/DashboardStats";
import ShiftCalendar from "@/components/ShiftCalendar";
import EmployeeList from "@/components/EmployeeList";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center">
                <CalendarDays className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Vardiya Yönetim</h1>
                <p className="text-sm text-muted-foreground">Sistem Paneli</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Ayarlar
              </Button>
              <Button size="sm" className="bg-gradient-primary">
                <UserPlus className="w-4 h-4 mr-2" />
                Çalışan Ekle
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats Section */}
        <div className="mb-8 animate-fade-in">
          <DashboardStats />
        </div>

        {/* Calendar and Employee List */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Shift Calendar */}
          <div className="lg:col-span-2 animate-fade-in" style={{ animationDelay: "0.1s" }}>
            <Card className="shadow-lg border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  Vardiya Takvimi
                </CardTitle>
                <CardDescription>Haftalık vardiya programı</CardDescription>
              </CardHeader>
              <CardContent>
                <ShiftCalendar />
              </CardContent>
            </Card>
          </div>

          {/* Employee List */}
          <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <Card className="shadow-lg border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-secondary" />
                  Çalışan Listesi
                </CardTitle>
                <CardDescription>Aktif çalışanlar</CardDescription>
              </CardHeader>
              <CardContent>
                <EmployeeList />
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 animate-fade-in" style={{ animationDelay: "0.3s" }}>
          <Card className="shadow-md border-border/50 hover:shadow-lg transition-all cursor-pointer bg-gradient-card">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Vardiya Oluştur</h3>
                <p className="text-sm text-muted-foreground">Yeni vardiya planla</p>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50 hover:shadow-lg transition-all cursor-pointer bg-gradient-card">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Çalışan Yönetimi</h3>
                <p className="text-sm text-muted-foreground">Personel düzenle</p>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50 hover:shadow-lg transition-all cursor-pointer bg-gradient-card">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-info" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Raporlar</h3>
                <p className="text-sm text-muted-foreground">İstatistikleri gör</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Index;
